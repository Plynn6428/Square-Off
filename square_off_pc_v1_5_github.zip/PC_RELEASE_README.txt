SQUARE OFF PC 1.5
=================
Standalone PC game: pc/index.html

Open pc/index.html in a desktop browser to play.

GitHub + Netlify deployment (keep the mobile version working):
  - Keep your existing root index.html (the 1.4 mobile version) unchanged.
  - Copy the pc folder to the ROOT of the GitHub repository.
  - Make sure the final repository layout is:
      index.html         (existing mobile version)
      pc/index.html      (new Square Off PC 1.5)
  - Commit changes. When Netlify publishes, PC is available at:
      https://playsquareoff.netlify.app/pc/
  - Your mobile version remains at:
      https://playsquareoff.netlify.app/

Controls: A/D move, W jump, S drop, Mouse aim,
Space or click shoot, E/F shield, Escape pause.
Only solo versus bot is available in PC 1.5.
